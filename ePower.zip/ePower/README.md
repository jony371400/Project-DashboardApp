# Backend Project

> Env Setting
```
$ pip install Flask-Cors
$ pip install requests
$ pip install Flask
$ pip install Socketio
```

> Execute Project
```
$ python ePower_Api.py
```